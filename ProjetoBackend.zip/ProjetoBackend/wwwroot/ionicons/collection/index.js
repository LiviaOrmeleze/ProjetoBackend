export { setAssetPath } from '@stencil/core';
export { addIcons } from './components/icon/utils';
